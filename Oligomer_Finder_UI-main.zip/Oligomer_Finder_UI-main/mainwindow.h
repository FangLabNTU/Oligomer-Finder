#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTabWidget>
#include <QRadioButton>
#include <QGroupBox>
#include <QPushButton>
#include <QTextEdit>
#include <QMenuBar>
#include <QVector>
#include <QTemporaryDir>
#include <QMessageBox>
#include <QProcess>

#include "Widgets/file_path_editor.h"
#include "Widgets/label_value_editor.h"
#include "Widgets/user_setting_widget.h"
#include "DataModel/finder_params.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

/*
 * Structure to store app settings
 */
struct AppSettings {
   QString rscript_path = "";
   QString pandoc_path = "";
   bool show_about_when_startup = true; // By default, show the about dialog when opening the application.
};

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void runOligomerFinder();
    void runHomologueFinder();
    void runCongenerFinder();
    void executeCommand(const QString& program, const QStringList& args);

    void onOpenSettings();
    void onQuitClicked();
    void onAboutClicked();
    void onShowAboutStartupToggled(bool);
    void onRscriptPathChanged(const QString& path);
    void onPandocPathChanged(const QString& path);
    void onStandardOutputRead();
    void onProcessStarted();
    void onProcessFinished(int exitCode, QProcess::ExitStatus exitStatus);

private:
    void buildOligTab_(QWidget* tab);
    void buildHomoTab_(QWidget* tab);
    void buildCongTab_(QWidget* tab);
    void buildAboutDialog_();

    bool exportOligParams_();
    bool exportHomoParams_();
    bool exportCongParams_();
    bool exportParams_(const QString& path, const QVector<QWidget*>& widgets);

    void initApp_();
    void readAppSettings_();
    void writeAppSettings_();
    void initTemporaryDir_();
    void copyScripts_();

    void appendLogInfo_(QString text);

    /* Read user input parameters from the user interface. */
    bool getOligSettings_(OligomerParams& params);
    bool getHomoSettings_(HomologueParams& params);
    bool getCongSettings_(CongenerParams& params);

private:
    const QString company_name_ = "FudanUniversity";
    const QString app_name_ = "OligomerFinder";

    /* Menu bar */
    QMenuBar* menu_bar_;

    /* Log displayer */
    QTextEdit* log_display_;

    /* Setting dialog */
    UserSettingWidget* settings_widget_;

    /* Tabs */
    QTabWidget* tab_widget_;
    QWidget* tab_oligomer_finder_;
    QWidget* tab_homologue_finder_;
    QWidget* tab_congener_finder_;

    /* Oligomer finder */
    FilePathEditor* olig_ms2_folder_;
    QRadioButton* olig_pos_;
    QRadioButton* olig_neg_;
    LabelValueEditor* olig_abundance_cut_off_;
    LabelValueEditor* olig_loss_cal_accuracy_;
    LabelValueEditor* olig_end_grp_cal_accuracy_;
    LabelValueEditor* olig_rt_begin_;
    LabelValueEditor* olig_rt_end_;
    LabelValueEditor* olig_loss_cut_off_;
    QGroupBox* olig_db_matching_grp_;
    FilePathEditor* olig_db_path_;
    FilePathEditor* olig_output_file_;
    QPushButton* olig_start_;

    /* Homologue finder */
    FilePathEditor* homo_seed_olig_file_;
    FilePathEditor* homo_ms1_peak_file_;
    QRadioButton* homo_pos_;
    QRadioButton* homo_neg_;
    QGroupBox* homo_deducting_blanks_grp_;
    FilePathEditor* homo_blank_file_;
    LabelValueEditor* homo_rt_tolerance_;
    LabelValueEditor* homo_mz_tolerance_;
    LabelValueEditor* homo_intensity_cut_off_;
    LabelValueEditor* homo_mass_tolerance_1_;
    LabelValueEditor* homo_mass_tolerance_2_;
    LabelValueEditor* homo_rt_begin_;
    LabelValueEditor* homo_rt_end_;
    LabelValueEditor* homo_unstable_cut_off_;
    QGroupBox* homo_annotation_grp_;
    FilePathEditor* homo_olig_db_file_;
    FilePathEditor* homo_output_dir_;
    QPushButton* homo_start_;

    /* Congener finder */
    FilePathEditor* cong_seed_olig_file_;
    FilePathEditor* cong_ms1_peak_file_;
    QRadioButton* cong_pos_;
    QRadioButton* cong_neg_;
    QGroupBox* cong_deducting_blanks_grp_;
    FilePathEditor* cong_blank_file_;
    LabelValueEditor* cong_rt_tolerance_;
    LabelValueEditor* cong_mz_tolerance_;
    LabelValueEditor* cong_intensity_cut_off_;
    FilePathEditor* cong_end_grp_db_file_;
    LabelValueEditor* cong_mass_tolerance_1_;
    LabelValueEditor* cong_mass_tolerance_2_;
    FilePathEditor* cong_output_dir_;
    QPushButton* cong_start_;

    QVector<QWidget*> olig_widgets;
    QVector<QWidget*> homo_widgets;
    QVector<QWidget*> cong_widgets;

    /* About dialog */
    QMessageBox* about_box_;

    /* Settings of this app */
    AppSettings app_settings_;

    QProcess* m_process;

    QTemporaryDir* temp_dir_;
    QString olig_rmd_path_;
    QString homo_rmd_path_;
    QString cong_rmd_path_;
    QString render_r_path_;
};
#endif // MAINWINDOW_H
