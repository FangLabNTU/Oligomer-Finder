#include "mainwindow.h"
#include <cstdlib>
#include <QVBoxLayout>
#include <QButtonGroup>
#include <QDoubleValidator>
#include <QMessageBox>
#include <QCoreApplication>
#include <QFileInfo>
#include <QDir>
#include <QSettings>
#include <QTemporaryFile>
#include <QResource>
#include <QCheckBox>

#include <QDebug>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    QVBoxLayout* window_layout = new QVBoxLayout;
    QWidget* centralWidget = new QWidget(this);
    centralWidget->setLayout(window_layout);
    setCentralWidget(centralWidget);

    setWindowTitle("Oligomer Finder");
    setWindowIcon(QIcon(":/Resources/Images/icon.ico"));

    tab_widget_ = new QTabWidget(this);
    window_layout->addWidget(tab_widget_);

    // Set up menu bar
    menu_bar_ = new QMenuBar(this);
    this->setMenuBar(menu_bar_);
    menuBar()->setNativeMenuBar(false); // Need this line, otherwise the menu bar not showing

    QMenu* menu_file = new QMenu("Option");
    menu_bar_->addMenu(menu_file);
    QAction* action_settings = new QAction("Settings...");
    menu_file->addAction(action_settings);
    connect(action_settings, SIGNAL(triggered(bool)), this, SLOT(onOpenSettings()));

    QAction* action_quit = new QAction("Quit");
    menu_file->addAction(action_quit);
    connect(action_quit, SIGNAL(triggered(bool)), this, SLOT(onQuitClicked()));

    QMenu* menu_help = new QMenu("Help");
    menu_bar_->addMenu(menu_help);
    QAction* action_about = new QAction("About...");
    menu_help->addAction(action_about);
    connect(action_about, SIGNAL(triggered(bool)), this, SLOT(onAboutClicked()));

    // Create setting dialog
    settings_widget_ = new UserSettingWidget("Settings");
    connect(settings_widget_, SIGNAL(onRscriptPathChanged(const QString&)), this, SLOT(onRscriptPathChanged(const QString&)));
    connect(settings_widget_, SIGNAL(onPandocPathChanged(const QString&)), this, SLOT(onPandocPathChanged(const QString&)));

    // Create and add tabs
    tab_oligomer_finder_ = new QWidget();
    tab_homologue_finder_ = new QWidget();
    tab_congener_finder_ = new QWidget();

    tab_widget_->addTab(tab_oligomer_finder_, "Oligomer Finder");
    tab_widget_->addTab(tab_homologue_finder_, "Homologue Finder");
    tab_widget_->addTab(tab_congener_finder_, "Congener Finder");

    buildOligTab_(tab_oligomer_finder_);
    buildHomoTab_(tab_homologue_finder_);
    buildCongTab_(tab_congener_finder_);

    buildAboutDialog_();

    // Initialize internal data
    initApp_();

    if (app_settings_.show_about_when_startup)
        about_box_->exec();

    m_process = new QProcess(this);
    connect(m_process, SIGNAL(readyReadStandardOutput()), this, SLOT(onStandardOutputRead()));
    connect(m_process, SIGNAL(started()), this, SLOT(onProcessStarted()));
    connect(m_process, SIGNAL(finished(int, QProcess::ExitStatus)), this, SLOT(onProcessFinished(int, QProcess::ExitStatus)));

    // Create the log displayer
    window_layout->addWidget(new QLabel("Log information"));
    log_display_ = new QTextEdit(this);
    log_display_->setReadOnly(true);
    window_layout->addWidget(log_display_);
}

MainWindow::~MainWindow()
{
    // Remove the temporary directory and all its files and directory under it.
    if (temp_dir_ != nullptr) {
        if (temp_dir_->remove()) {
            qDebug() << "Remove operation successful!";
        } else {
            qDebug() << "Remove operation Unsuccessful!";
        }

        delete temp_dir_;
    }
}

/*
 * Build the Oligomer finder tab
 */
void MainWindow::buildOligTab_(QWidget *tab)
{
    /* Initialize widgets */
    olig_ms2_folder_ = new FilePathEditor("MS2 file (.mat) folder", FilePathEditor::OPEN_DIRECTORY);
    olig_ms2_folder_->setObjectName("olig_ms2_folder_");
    olig_widgets.push_back(olig_ms2_folder_);

    olig_pos_ = new QRadioButton("Positive");
    olig_pos_->setObjectName("olig_pos_");
    olig_widgets.push_back(olig_pos_);
    olig_neg_ = new QRadioButton("Negative");
    olig_neg_->setObjectName("olig_neg_");
    olig_widgets.push_back(olig_neg_);

    olig_abundance_cut_off_ = new LabelValueEditor("MS/MS abundance cut off");
    olig_abundance_cut_off_->setValidator(new QDoubleValidator(0, 1, 10));
    olig_abundance_cut_off_->setTip("Value range: [0, 1]");
    olig_abundance_cut_off_->setObjectName("olig_abundance_cut_off_");
    olig_widgets.push_back(olig_abundance_cut_off_);

    olig_loss_cal_accuracy_ = new LabelValueEditor("Repeated neutral loss calculation accuracy");
    olig_loss_cal_accuracy_->setValidator(new QIntValidator(1, 20));
    olig_loss_cal_accuracy_->setTip("Number of digits after the decimal point. For Q-TOF, 2 is better.");
    olig_loss_cal_accuracy_->setObjectName("olig_loss_cal_accuracy_");
    olig_widgets.push_back(olig_loss_cal_accuracy_);

    olig_end_grp_cal_accuracy_ = new LabelValueEditor("End group calculation accuracy");
    olig_end_grp_cal_accuracy_->setValidator(new QIntValidator(1, 20));
    olig_end_grp_cal_accuracy_->setTip("Number of digits after the decimal point. For Q-TOF, 1 is better.");
    olig_end_grp_cal_accuracy_->setObjectName("olig_end_grp_cal_accuracy_");
    olig_widgets.push_back(olig_end_grp_cal_accuracy_);

    olig_rt_begin_ = new LabelValueEditor("Retention time begin (min)");
    olig_rt_begin_->setObjectName("olig_rt_begin_");
    olig_widgets.push_back(olig_rt_begin_);
    olig_rt_end_ = new LabelValueEditor("Retention time end (min)");
    olig_rt_end_->setObjectName("olig_rt_end_");
    olig_widgets.push_back(olig_rt_end_);
    olig_loss_cut_off_ = new LabelValueEditor("Repeated neutral loss cut off (Da)");
    olig_loss_cut_off_->setValidator(new QDoubleValidator(0, 1, 20));
    olig_loss_cut_off_->setTip("Value range: [0, 1]");
    olig_loss_cut_off_->setObjectName("olig_loss_cut_off_");
    olig_widgets.push_back(olig_loss_cut_off_);

    olig_db_path_ = new FilePathEditor("Oligomer database file (.xlsx)", FilePathEditor::OPEN_FILE);
    olig_db_path_->setObjectName("olig_db_path_");
    olig_widgets.push_back(olig_db_path_);

    olig_output_file_ = new FilePathEditor("Directory of result file (.csv)", FilePathEditor::SAVE_FILE);
    olig_output_file_->setObjectName("olig_output_file_");
    olig_widgets.push_back(olig_output_file_);

    olig_start_ = new QPushButton("Start");
    olig_start_->setObjectName("olig_start_");
    olig_widgets.push_back(olig_start_);

    /* Add widgets to the tab */
    QHBoxLayout* layout = new QHBoxLayout(tab);
    layout->setMargin(0);

    QVBoxLayout* left = new QVBoxLayout();
    left->setMargin(0);
    QVBoxLayout* right = new QVBoxLayout();
    right->setMargin(0);
    layout->addLayout(left);
    layout->addLayout(right);

    // Data path(s)
    QGroupBox* data_path_grp = new QGroupBox("Data path");
    QVBoxLayout* data_path_grp_layout = new QVBoxLayout(data_path_grp);
    data_path_grp_layout->setMargin(0);
    data_path_grp_layout->addWidget(olig_ms2_folder_);
    left->addWidget(data_path_grp);

    // Ion mode
    QButtonGroup* button_grp = new QButtonGroup(tab);
    olig_pos_->setChecked(true);
    button_grp->addButton(olig_pos_);
    button_grp->addButton(olig_neg_);
    QHBoxLayout* buttons_layout = new QHBoxLayout();
    buttons_layout->addWidget(olig_pos_);
    buttons_layout->addWidget(olig_neg_);
    QGroupBox* ion_mode_grp = new QGroupBox("Ion mode");
    QVBoxLayout* ion_mode_grp_layout = new QVBoxLayout(ion_mode_grp);
    ion_mode_grp_layout->addLayout(buttons_layout);
    left->addWidget(ion_mode_grp);

    // Calculation mode
    QGroupBox* cal_mode_grp = new QGroupBox("Calculation mode");
    QVBoxLayout* cal_mode_grp_layout = new QVBoxLayout(cal_mode_grp);
    cal_mode_grp_layout->setMargin(0);
    cal_mode_grp_layout->addWidget(olig_abundance_cut_off_);
    cal_mode_grp_layout->addWidget(olig_loss_cal_accuracy_);
    cal_mode_grp_layout->addWidget(olig_end_grp_cal_accuracy_);
    left->addWidget(cal_mode_grp);

    // Result filter
    QGroupBox* result_filter_grp = new QGroupBox("Result filter");
    QVBoxLayout* result_filter_grp_layout = new QVBoxLayout(result_filter_grp);
    result_filter_grp_layout->setMargin(0);
    result_filter_grp_layout->addWidget(olig_rt_begin_);
    result_filter_grp_layout->addWidget(olig_rt_end_);
    result_filter_grp_layout->addWidget(olig_loss_cut_off_);
    right->addWidget(result_filter_grp);

    // Database matching
    QGroupBox* db_matching_grp = new QGroupBox("Database matching");
    QVBoxLayout* db_matching_grp_layout = new QVBoxLayout(db_matching_grp);
    db_matching_grp->setCheckable(true);
    db_matching_grp->setChecked(true);
    olig_db_matching_grp_ = db_matching_grp; // Future access to the checkbox
    db_matching_grp_layout->setMargin(0);
    db_matching_grp_layout->addWidget(olig_db_path_);
    right->addWidget(db_matching_grp);

    // Output path
    QGroupBox* output_path = new QGroupBox("Output path");
    QVBoxLayout* output_path_layout = new QVBoxLayout(output_path);
    output_path_layout->setMargin(0);
    output_path_layout->addWidget(olig_output_file_);
    right->addWidget(output_path);

    // Start button
    right->addWidget(olig_start_);
    connect(olig_start_, SIGNAL(clicked(bool)), this, SLOT(runOligomerFinder()));
}

void MainWindow::buildHomoTab_(QWidget* tab)
{
    /* Initialize widgets */

    // Data paths
    homo_seed_olig_file_ = new FilePathEditor("Seed Oligomer file (.xlsx)", FilePathEditor::OPEN_FILE);
    homo_seed_olig_file_->setObjectName("homo_seed_olig_file_");
    homo_widgets.push_back(homo_seed_olig_file_);
    homo_ms1_peak_file_ = new FilePathEditor("MS1 peak table file (.txt)", FilePathEditor::OPEN_FILE);
    homo_ms1_peak_file_->setObjectName("homo_ms1_peak_file_");
    homo_widgets.push_back(homo_ms1_peak_file_);

    // Ion mode
    homo_pos_ = new QRadioButton("Positive");
    homo_pos_->setObjectName("homo_pos_");
    homo_widgets.push_back(homo_pos_);
    homo_neg_ = new QRadioButton("Negative");
    homo_neg_->setObjectName("homo_neg_");
    homo_widgets.push_back(homo_neg_);

    // Deducting blanks
    homo_blank_file_ = new FilePathEditor("Blank file (.txt)", FilePathEditor::OPEN_FILE);
    homo_blank_file_->setObjectName("homo_blank_file_");
    homo_widgets.push_back(homo_blank_file_);

    homo_rt_tolerance_ = new LabelValueEditor("Retention time tolerance (min)");
    homo_rt_tolerance_->setObjectName("homo_rt_tolerance_");
    homo_widgets.push_back(homo_rt_tolerance_);

    homo_mz_tolerance_ = new LabelValueEditor("m//z tolerance (Da)");
    homo_mz_tolerance_->setObjectName("homo_mz_tolerance_");
    homo_widgets.push_back(homo_mz_tolerance_);

    homo_intensity_cut_off_ = new LabelValueEditor("Intensity proportion cut off (0-1)");
    homo_intensity_cut_off_->setValidator(new QDoubleValidator(0, 1, 10));
    homo_intensity_cut_off_->setTip("Value range: [0, 1]");
    homo_intensity_cut_off_->setObjectName("homo_intensity_cut_off_");
    homo_widgets.push_back(homo_intensity_cut_off_);

    // Homologue analysis
    homo_mass_tolerance_1_ = new LabelValueEditor("Mass tolerance 1 (ppm)");
    homo_mass_tolerance_1_->setTip("Resolution of MS instrument");
    homo_mass_tolerance_1_->setObjectName("homo_mass_tolerance_1_");
    homo_widgets.push_back(homo_mass_tolerance_1_);


    homo_mass_tolerance_2_ = new LabelValueEditor("Mass tolerance 2 (ppm)");
    homo_mass_tolerance_2_->setTip("Mass tolerance of the NL in \"seed\"");
    homo_mass_tolerance_2_->setObjectName("homo_mass_tolerance_2_");
    homo_widgets.push_back(homo_mass_tolerance_2_);

    // Retention time predictor
    homo_rt_begin_ = new LabelValueEditor("Retention time begin (min)");
    homo_rt_begin_->setObjectName("homo_rt_begin_");
    homo_widgets.push_back(homo_rt_begin_);

    homo_rt_end_ = new LabelValueEditor("Retention time end (min)");
    homo_rt_end_->setObjectName("homo_rt_end_");
    homo_widgets.push_back(homo_rt_end_);

    homo_unstable_cut_off_ = new LabelValueEditor("Unstable gradient time cut off (0-1)");
    homo_unstable_cut_off_->setValidator(new QDoubleValidator(0, 1, 20));
    homo_unstable_cut_off_->setTip("Value range: [0, 1]");
    homo_unstable_cut_off_->setObjectName("homo_unstable_cut_off_");
    homo_widgets.push_back(homo_unstable_cut_off_);

    // Annotation
    homo_olig_db_file_ = new FilePathEditor("Oligomer database (.xlsx)");
    homo_olig_db_file_->setObjectName("homo_olig_db_file_");
    homo_widgets.push_back(homo_olig_db_file_);

    // Output path
    homo_output_dir_ = new FilePathEditor("Directory folder");
    homo_output_dir_->setObjectName("homo_output_dir_");
    homo_widgets.push_back(homo_output_dir_);

    // Start button
    homo_start_ = new QPushButton("Start");
    homo_start_->setObjectName("homo_start_");
    homo_widgets.push_back(homo_start_);


    /* Add widgets to the tab */
    QHBoxLayout* layout = new QHBoxLayout(tab);
    layout->setMargin(0);

    QVBoxLayout* left = new QVBoxLayout();
    left->setMargin(0);
    QVBoxLayout* right = new QVBoxLayout();
    right->setMargin(0);
    layout->addLayout(left);
    layout->addLayout(right);

    // Paths
    QGroupBox* data_paths_grp = new QGroupBox("Data path");
    QVBoxLayout* data_paths_grp_layout = new QVBoxLayout(data_paths_grp);
    data_paths_grp_layout->setMargin(0);
    data_paths_grp_layout->addWidget(homo_seed_olig_file_);
    data_paths_grp_layout->addWidget(homo_ms1_peak_file_);
    left->addWidget(data_paths_grp);

    // Ion mode
    QButtonGroup* button_grp = new QButtonGroup(tab);
    homo_pos_->setChecked(true);
    button_grp->addButton(homo_pos_);
    button_grp->addButton(homo_neg_);
    QHBoxLayout* buttons_layout = new QHBoxLayout();
    buttons_layout->addWidget(homo_pos_);
    buttons_layout->addWidget(homo_neg_);
    QGroupBox* ion_mode_grp = new QGroupBox("Ion mode");
    QVBoxLayout* ion_mode_grp_layout = new QVBoxLayout(ion_mode_grp);
    ion_mode_grp_layout->addLayout(buttons_layout);
    left->addWidget(ion_mode_grp);

    // Deducting blanks
    QGroupBox* deducting_blanks_grp = new QGroupBox("Deducting blanks");
    deducting_blanks_grp->setCheckable(true);
    deducting_blanks_grp->setChecked(true);
    homo_deducting_blanks_grp_= deducting_blanks_grp; // Future access to the checkbox
    QVBoxLayout* deducting_blanks_grp_layout = new QVBoxLayout(deducting_blanks_grp);
    deducting_blanks_grp_layout->setMargin(0);
    deducting_blanks_grp_layout->addWidget(homo_blank_file_);
    deducting_blanks_grp_layout->addWidget(homo_rt_tolerance_);
    deducting_blanks_grp_layout->addWidget(homo_mz_tolerance_);
    deducting_blanks_grp_layout->addWidget(homo_intensity_cut_off_);
    left->addWidget(deducting_blanks_grp);

    // Homologue analysis
    QGroupBox* homo_analysis_grp = new QGroupBox("Homologue analysis");
    QVBoxLayout* homo_analysis_grp_layout = new QVBoxLayout(homo_analysis_grp);
    homo_analysis_grp_layout->setMargin(0);
    homo_analysis_grp_layout->addWidget(homo_mass_tolerance_1_);
    homo_analysis_grp_layout->addWidget(homo_mass_tolerance_2_);
    right->addWidget(homo_analysis_grp);

    // Retention time predictor
    QGroupBox* rt_predictor_grp = new QGroupBox("Retention time predictor");
    QVBoxLayout* rt_predictor_grp_layout = new QVBoxLayout(rt_predictor_grp);
    rt_predictor_grp_layout->setMargin(0);
    rt_predictor_grp_layout->addWidget(homo_rt_begin_);
    rt_predictor_grp_layout->addWidget(homo_rt_end_);
    rt_predictor_grp_layout->addWidget(homo_unstable_cut_off_);
    right->addWidget(rt_predictor_grp);

    // Annotation
    QGroupBox* annotation_grp = new QGroupBox("Annotation");
    QVBoxLayout* annotation_grp_layout = new QVBoxLayout(annotation_grp);
    annotation_grp->setCheckable(true);
    annotation_grp->setChecked(true);
    homo_annotation_grp_ = annotation_grp; // Future accesss to the checkbox
    annotation_grp_layout->setMargin(0);
    annotation_grp_layout->addWidget(homo_olig_db_file_);
    right->addWidget(annotation_grp);

    // Output path
    QGroupBox* output_grp = new QGroupBox("Output path");
    QVBoxLayout* output_grp_layout = new QVBoxLayout(output_grp);
    output_grp_layout->setMargin(0);
    output_grp_layout->addWidget(homo_output_dir_);
    right->addWidget(output_grp);

    // Start button
    right->addWidget(homo_start_);
    connect(homo_start_, SIGNAL(clicked(bool)), this, SLOT(runHomologueFinder()));
}

void MainWindow::buildCongTab_(QWidget* tab)
{
    /* Initialize widgets */

    // File paths
    cong_seed_olig_file_ = new FilePathEditor("Seed Oligomer file (.xlsx)", FilePathEditor::OPEN_FILE);
    cong_seed_olig_file_->setObjectName("cong_seed_olig_file_");
    cong_widgets.push_back(cong_seed_olig_file_);

    cong_ms1_peak_file_ = new FilePathEditor("MS1 peak table file (.txt)", FilePathEditor::OPEN_FILE);
    cong_ms1_peak_file_->setObjectName("cong_ms1_peak_file_");
    cong_widgets.push_back(cong_ms1_peak_file_);

    // Ion mode
    cong_pos_ = new QRadioButton("Positive");
    cong_pos_->setObjectName("cong_pos_");
    cong_widgets.push_back(cong_pos_);

    cong_neg_ = new QRadioButton("Negative");
    cong_neg_->setObjectName("cong_neg_");
    cong_widgets.push_back(cong_neg_);

    // Deducting blanks
    cong_blank_file_ = new FilePathEditor("Blank file (.txt)", FilePathEditor::OPEN_FILE);
    cong_blank_file_->setObjectName("cong_blank_file_");
    cong_widgets.push_back(cong_blank_file_);

    cong_rt_tolerance_ = new LabelValueEditor("Retention time tolerance (min)");
    cong_rt_tolerance_->setObjectName("cong_rt_tolerance_");
    cong_widgets.push_back(cong_rt_tolerance_);

    cong_mz_tolerance_ = new LabelValueEditor("m//z tolerance (Da)");
    cong_mz_tolerance_->setObjectName("cong_mz_tolerance_");
    cong_widgets.push_back(cong_mz_tolerance_);

    cong_intensity_cut_off_ = new LabelValueEditor("Intensity proportion cut off (0-1)");
    cong_intensity_cut_off_->setValidator(new QDoubleValidator(0, 1, 20));
    cong_intensity_cut_off_->setTip("Value range: [0, 1]");
    cong_intensity_cut_off_->setObjectName("cong_intensity_cut_off_");
    cong_widgets.push_back(cong_intensity_cut_off_);

    // Congener analysis
    cong_end_grp_db_file_ = new FilePathEditor("End group database (.xlsx)", FilePathEditor::OPEN_FILE);
    cong_end_grp_db_file_->setObjectName("cong_end_grp_db_file_");
    cong_widgets.push_back(cong_end_grp_db_file_);

    cong_mass_tolerance_1_ = new LabelValueEditor("Mass tolerance 1 (ppm)");
    cong_mass_tolerance_1_->setTip("Resolution of MS instrument");
    cong_mass_tolerance_1_->setObjectName("cong_mass_tolerance_1_");
    cong_widgets.push_back(cong_mass_tolerance_1_);

    cong_mass_tolerance_2_ = new LabelValueEditor("Mass tolerance 2 (ppm)");
    cong_mass_tolerance_2_->setTip("Mass tolerance of the NL in \"seed\"");
    cong_mass_tolerance_2_->setObjectName("cong_mass_tolerance_2_");
    cong_widgets.push_back(cong_mass_tolerance_2_);

    // Output dir
    cong_output_dir_ = new FilePathEditor("Directory folder", FilePathEditor::OPEN_DIRECTORY);
    cong_output_dir_->setObjectName("cong_output_dir_");
    cong_widgets.push_back(cong_output_dir_);

    // Start button
    cong_start_ = new QPushButton("Start");
    cong_start_->setObjectName("cong_start_");
    cong_widgets.push_back(cong_start_);

    /* Add widgets to the tab */
    QHBoxLayout* layout = new QHBoxLayout(tab);
    layout->setMargin(0);

    QVBoxLayout* left = new QVBoxLayout();
    left->setMargin(0);
    QVBoxLayout* right = new QVBoxLayout();
    right->setMargin(0);
    layout->addLayout(left);
    layout->addLayout(right);

    // Data paths
    QGroupBox* data_path_grp = new QGroupBox("Data path");
    QVBoxLayout* data_path_grp_layout = new QVBoxLayout(data_path_grp);
    data_path_grp_layout->setMargin(0);
    data_path_grp_layout->addWidget(cong_seed_olig_file_);
    data_path_grp_layout->addWidget(cong_ms1_peak_file_);
    left->addWidget(data_path_grp);

    // Ion mode
    QButtonGroup* button_grp = new QButtonGroup(tab);
    cong_pos_->setChecked(true);
    button_grp->addButton(cong_pos_);
    button_grp->addButton(cong_neg_);
    QHBoxLayout* buttons_layout = new QHBoxLayout();
    buttons_layout->addWidget(cong_pos_);
    buttons_layout->addWidget(cong_neg_);
    QGroupBox* ion_mode_grp = new QGroupBox("Ion mode");
    QVBoxLayout* ion_mode_grp_layout = new QVBoxLayout(ion_mode_grp);
    ion_mode_grp_layout->addLayout(buttons_layout);
    left->addWidget(ion_mode_grp);

    // Deducting blanks
    QGroupBox* deducting_blanks_grp = new QGroupBox("Deducting blanks");
    deducting_blanks_grp->setCheckable(true);
    deducting_blanks_grp->setChecked(true);
    cong_deducting_blanks_grp_ = deducting_blanks_grp; // Future access to the checkbox
    QVBoxLayout* deducting_blanks_grp_layout = new QVBoxLayout(deducting_blanks_grp);
    deducting_blanks_grp_layout->setMargin(0);
    deducting_blanks_grp_layout->addWidget(cong_blank_file_);
    deducting_blanks_grp_layout->addWidget(cong_rt_tolerance_);
    deducting_blanks_grp_layout->addWidget(cong_mz_tolerance_);
    deducting_blanks_grp_layout->addWidget(cong_intensity_cut_off_);
    left->addWidget(deducting_blanks_grp);

    // Congener analysis
    QGroupBox* cong_analysis_grp = new QGroupBox("Congener analysis");
    QVBoxLayout* cong_analysis_grp_layout = new QVBoxLayout(cong_analysis_grp);
    cong_analysis_grp_layout->setMargin(0);
    cong_analysis_grp_layout->addWidget(cong_end_grp_db_file_);
    cong_analysis_grp_layout->addWidget(cong_mass_tolerance_1_);
    cong_analysis_grp_layout->addWidget(cong_mass_tolerance_2_);
    right->addWidget(cong_analysis_grp);

    // Output path
    QGroupBox* output_grp = new QGroupBox("Output path");
    QVBoxLayout* output_grp_layout = new QVBoxLayout(output_grp);
    output_grp_layout->setMargin(0);
    output_grp_layout->addWidget(cong_output_dir_);
    right->addWidget(output_grp);

    // Start button
    right->addWidget(cong_start_);
    connect(cong_start_, SIGNAL(clicked(bool)), this, SLOT(runCongenerFinder()));
}

/*
 * Build the "About" dialog which is shown when user clicks "Help > About"
 */
void MainWindow::buildAboutDialog_()
{
    about_box_ = new QMessageBox();
    QPixmap iconPixmap(":/Resources/Images/icon.svg");
    iconPixmap = iconPixmap.scaled(128, 128, Qt::KeepAspectRatio);
    about_box_->setIconPixmap(iconPixmap);
    about_box_->setWindowTitle("About Oligomer Finder");
    about_box_->setText("Oligomer Finder");

    QString content = "";
    QFile about_file(":/Resources/Texts/about.txt");
    if (about_file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream in(&about_file);
        content = in.readAll();
        about_file.close();
    }
    about_box_->setInformativeText(content);

    about_box_->setStandardButtons(QMessageBox::Close);
    about_box_->setDefaultButton(QMessageBox::Close);

    QCheckBox* cb = new QCheckBox("Show when startup.");
    about_box_->setCheckBox(cb);
    connect(cb, SIGNAL(toggled(bool)), this, SLOT(onShowAboutStartupToggled(bool)));
}

/*
 * Export the user input parameters for Oligomer finder
 */
bool MainWindow::exportOligParams_()
{
    return exportParams_("OligParams.txt", olig_widgets);
}

/*
 * Export the user input parameters for Homologue finder
 */
bool MainWindow::exportHomoParams_()
{
    return exportParams_("HomoParams.txt", homo_widgets);
}

/*
 * Export the user input parameters for Congener finder
 */
bool MainWindow::exportCongParams_()
{
    return exportParams_("CongParams.txt", cong_widgets);
}

bool MainWindow::exportParams_(const QString &path, const QVector<QWidget*> &widgets)
{
    if (path.isEmpty())
        return false;

    QFile file(path);
    file.open(QIODevice::ReadWrite | QIODevice::Text);

    QString content = "";
    for (int i = 0; i < widgets.size(); ++i) {
        QWidget* widget = widgets[i];
        if (dynamic_cast<FilePathEditor*>(widget) != nullptr) {
            FilePathEditor* w = dynamic_cast<FilePathEditor*>(widget);
            content += w->objectName() + QString("=") + w->getFilePath();
        } else if (dynamic_cast<QRadioButton*>(widget) != nullptr) {
            QRadioButton*  w = dynamic_cast<QRadioButton*>(widget);
            content += w->objectName() + QString("=") + QString(w->isChecked()? "true" : "false");
        } else if (dynamic_cast<LabelValueEditor*>(widget) != nullptr) {
            LabelValueEditor* w = dynamic_cast<LabelValueEditor*>(widget);
            content += w->objectName() += QString("=") + w->getText();
        } else if (dynamic_cast<QPushButton*>(widget) != nullptr) {
            // Do nothing
            continue;
        }
        content += "\n";
    }
    file.write(content.toUtf8());
    return true;
}

void MainWindow::initApp_()
{
    readAppSettings_();
    initTemporaryDir_();
    copyScripts_();
}

void MainWindow::readAppSettings_()
{
    QSettings settings(company_name_, app_name_);

    app_settings_.rscript_path = settings.value("RSCRIPT_PATH", "").toString();
    if (!app_settings_.rscript_path.isEmpty()) {
        // Set this path in the setting dialog.
        settings_widget_->setRscriptPath(app_settings_.rscript_path);
    }

    app_settings_.pandoc_path = settings.value("PANDOC_PATH", "").toString();
    if (!app_settings_.pandoc_path.isEmpty()) {
        // Set this path in the setting dialog
        settings_widget_->setPandocPath(app_settings_.pandoc_path);
    }

    if (settings.contains("SHOW_ABOUT_WHEN_STARTUP"))
        app_settings_.show_about_when_startup = settings.value("SHOW_ABOUT_WHEN_STARTUP", "").toBool();
    else
        app_settings_.show_about_when_startup = true; // By default, show the dialog


    disconnect(about_box_->checkBox(), SIGNAL(toggled(bool)), this, SLOT(onShowAboutStartupToggled(bool)));
    about_box_->checkBox()->setChecked(app_settings_.show_about_when_startup);
    connect(about_box_->checkBox(), SIGNAL(toggled(bool)), this, SLOT(onShowAboutStartupToggled(bool)));
}

void MainWindow::writeAppSettings_()
{
    QSettings settings(company_name_, app_name_);
    settings.setValue("RSCRIPT_PATH", app_settings_.rscript_path);
    settings.setValue("PANDOC_PATH", app_settings_.pandoc_path);
    settings.setValue("SHOW_ABOUT_WHEN_STARTUP", app_settings_.show_about_when_startup);
}

void MainWindow::initTemporaryDir_()
{
    temp_dir_ = new QTemporaryDir();

    if (temp_dir_->isValid()) {
        // The QTemporaryDir instance is valid
        qDebug() << "Temporary directory is valid. Path: " << temp_dir_->path();
    } else {
        // The QTemporaryDir instance is not valid
        qDebug() << "Failed to create a temporary directory.";
    }

}

void MainWindow::copyScripts_()
{
    // Copy Rmd scripts to the temporary file.
    if (temp_dir_->isValid()) {
        // Copy Oligomer Finder script
        QFile olig_rmd(":/Resources/Scripts/Oligomer_Finder.Rmd");  // Replace with your resource path
        olig_rmd_path_ = QDir(temp_dir_->path()).filePath("Oligomer_Finder.Rmd");
        if (olig_rmd.copy(olig_rmd_path_)) {
            qDebug() << "Resource file copied to temporary directory.";
        } else {
            qWarning() << "Failed to copy resource file to temporary directory.";
        }

        // Copy Homologue Finder script
        QFile homo_rmd(":/Resources/Scripts/Homologue_Finder.Rmd");  // Replace with your resource path
        homo_rmd_path_ = QDir(temp_dir_->path()).filePath("Homologue_Finder.Rmd");
        if (homo_rmd.copy(homo_rmd_path_)) {
            qDebug() << "Resource file copied to temporary directory.";
        } else {
            qWarning() << "Failed to copy resource file to temporary directory.";
        }

        // Copy Congener Finder script
        QFile cong_rmd(":/Resources/Scripts/Congener_Finder.Rmd");  // Replace with your resource path
        cong_rmd_path_ = QDir(temp_dir_->path()).filePath("Congener_Finder.Rmd");
        if (cong_rmd.copy(cong_rmd_path_)) {
            qDebug() << "Resource file copied to temporary directory.";
        } else {
            qWarning() << "Failed to copy resource file to temporary directory.";
        }

        // Copy render script
        QFile render_r(":/Resources/Scripts/render.R");
        render_r_path_ = QDir(temp_dir_->path()).filePath("render.R");
        if (render_r.copy(render_r_path_)) {
            qDebug() << "Resource file copied to temporary directory.";
        } else {
            qWarning() << "Failed to copy resource file to temporary directory.";
        }
    }
}

void MainWindow::appendLogInfo_(QString text)
{
    log_display_->append(text);

    // Scroll to the bottom to show the latest message
    QTextCursor cursor = log_display_->textCursor();
    cursor.movePosition(QTextCursor::End);
    log_display_->setTextCursor(cursor);
}

void MainWindow::runOligomerFinder()
{
    // Clear the log display
    log_display_->clear();

    OligomerParams params;
    if (!getOligSettings_(params))
        return;
    QString rscript_path = app_settings_.rscript_path;
    if (rscript_path.isEmpty()) {
        QMessageBox::information(
                    this,
                    tr("Warning"),
                    tr("Please set rscript path!")
                );
        return;
    }

    // Export settings to the temporary directory
    QString setting_file_path = QDir(temp_dir_->path()).filePath("parameters.txt");
    QFile setting_file(setting_file_path);
    setting_file.open(QIODevice::WriteOnly | QIODevice::Text);

    qDebug() << setting_file_path;

    QString content = "";
    content += QString("Mode=%1\n").arg(QString(params.is_pos? "positive" : "negative"));
    content += QString("minint=%1\n").arg(QString::number(params.min_int));
    content += QString("RTmin=%1\n").arg(QString::number(params.rt_min));
    content += QString("RTmax=%1\n").arg(QString::number(params.rt_max));
    content += QString("NLmin=%1\n").arg(QString::number(params.nl_min));
    content += QString("Round_NL=%1\n").arg(QString::number(params.round_nl));
    content += QString("Round_Differ=%1\n").arg(QString::number(params.round_differ));
    content += QString("ppm=%1\n").arg(QString::number(params.ppm));
    content += QString("folder_path=%1\n").arg(params.folder_path);
    content += QString("Databasematching=%1\n").arg(QString::number(params.db_matching? 1 : 0));
    content += QString("database_path=%1\n").arg(params.db_path);
    content += QString("save_path=%1\n").arg(params.save_path);

    setting_file.write(content.toUtf8());
    setting_file.close();

    // Generate command to run the following command:
    // "Rscript render.R Oligomer setting_path rmd_path pandoc_path"
    QString method = "Oligomer";

    // Call the script by running command;
    QString program = app_settings_.rscript_path;
    QStringList args;
    args << render_r_path_ << method << setting_file_path << olig_rmd_path_ << app_settings_.pandoc_path;
    executeCommand(program, args);

    /*
    // Run using system()
    QString command;
    command += program;
    for (QString arg : args) {
        command += QString(" ") + arg;
    }
    system(command.toStdString().c_str());*/

    return;
}

void MainWindow::runHomologueFinder()
{
    // Clear the log display
    log_display_->clear();

    HomologueParams params;
    if (!getHomoSettings_(params))
        return;
    QString rscript_path = app_settings_.rscript_path;
    if (rscript_path.isEmpty()) {
        QMessageBox::information(
                    this,
                    tr("Warning"),
                    tr("Please set rscript path!")
                );
        return;
    }

    // Export settings to the temporary directory
    QString setting_file_path = QDir(temp_dir_->path()).filePath("parameters.txt");
    QFile setting_file(setting_file_path);
    setting_file.open(QIODevice::WriteOnly | QIODevice::Text);

    qDebug() << setting_file_path;

    QString content = "";
    content += QString("batch_path=%1\n").arg(params.batch_path);
    content += QString("peak_table_path=%1\n").arg(params.peak_table_path);
    content += QString("BK_path=%1\n").arg(params.bk_path);
    content += QString("ppm=%1\n").arg(QString::number(params.ppm));
    content += QString("filter=%1\n").arg(QString::number(params.filter? 1 : 0));
    content += QString("RT_diff=%1\n").arg(QString::number(params.rt_diff));
    content += QString("mz_diff=%1\n").arg(QString::number(params.mz_diff));
    content += QString("proportion=%1\n").arg(QString::number(params.proportion));
    content += QString("Mode=%1\n").arg(QString(params.is_pos? "positive" : "negative"));
    content += QString("error1=%1\n").arg(QString::number(params.error_1));
    content += QString("error2=%1\n").arg(QString::number(params.error_2));
    content += QString("RTmin=%1\n").arg(QString::number(params.rt_min));
    content += QString("RTmax=%1\n").arg(QString::number(params.rt_max));
    content += QString("RTlim=%1\n").arg(QString::number(params.rt_lim));
    content += QString("Annotate=%1\n").arg(QString::number(params.annotation? 1 : 0));
    content += QString("oligomer_database_path=%1\n").arg(params.oligomer_db_path);
    content += QString("save_path=%1\n").arg(params.save_path);

    setting_file.write(content.toUtf8());
    setting_file.close();

    // Generate command to run the following command:
    // "Rscript render.R Homologue setting_path rmd_path pandoc_path"
    QString method = "Homologue";

    // Call the script by running command;
    QString program = app_settings_.rscript_path;
    QStringList args;
    args << render_r_path_ << method << setting_file_path << homo_rmd_path_ << app_settings_.pandoc_path;
    executeCommand(program, args);

    return;
}

void MainWindow::runCongenerFinder()
{
    // Clear the log display
    log_display_->clear();

    CongenerParams params;
    if (!getCongSettings_(params))
        return;
    QString rscript_path = app_settings_.rscript_path;
    if (rscript_path.isEmpty()) {
        QMessageBox::information(
                    this,
                    tr("Warning"),
                    tr("Please set rscript path!")
                );
        return;
    }

    // Export settings to the temporary directory
    QString setting_file_path = QDir(temp_dir_->path()).filePath("parameters.txt");
    QFile setting_file(setting_file_path);
    setting_file.open(QIODevice::WriteOnly | QIODevice::Text);

    qDebug() << setting_file_path;

    QString content = "";
    content += QString("batch_path=%1\n").arg(params.batch_path);
    content += QString("peak_table_path=%1\n").arg(params.peak_table_path);
    content += QString("BK_path=%1\n").arg(params.bk_path);
    content += QString("ppm=%1\n").arg(QString::number(params.ppm));
    content += QString("filter=%1\n").arg(QString::number(params.filter? 1 : 0));
    content += QString("RT_diff=%1\n").arg(QString::number(params.rt_diff));
    content += QString("mz_diff=%1\n").arg(QString::number(params.mz_diff));
    content += QString("proportion=%1\n").arg(QString::number(params.proportion));
    content += QString("Mode=%1\n").arg(QString(params.is_pos? "positive" : "negative"));
    content += QString("End_group_database_path=%1\n").arg(params.end_gp_database_path);
    content += QString("error1=%1\n").arg(QString::number(params.error_1));
    content += QString("error2=%1\n").arg(QString::number(params.error_2));
    content += QString("save_path=%1\n").arg(params.save_path);

    setting_file.write(content.toUtf8());
    setting_file.close();

    // Generate command to run the following command:
    // "Rscript render.R Congener setting_path rmd_path pandoc_path"
    QString method = "Congener";

    // Call the script by running command;
    QString program = app_settings_.rscript_path;
    QStringList args;
    args << render_r_path_ << method << setting_file_path << cong_rmd_path_ << app_settings_.pandoc_path;
    executeCommand(program, args);

    return;
}

void MainWindow::executeCommand(const QString &program, const QStringList& args)
{
    m_process->start(program, args);
}

void MainWindow::onStandardOutputRead()
{
    QByteArray outputData = m_process->readAllStandardOutput();
    QString outputString = QString::fromUtf8(outputData);
    appendLogInfo_(outputString);
}

void MainWindow::onProcessStarted()
{
    tab_widget_->setEnabled(false);
    this->setCursor(Qt::WaitCursor);
}

void MainWindow::onProcessFinished(int exitCode, QProcess::ExitStatus exitStatus)
{
    tab_widget_->setEnabled(true);
    if (exitStatus == QProcess::NormalExit) {
        appendLogInfo_("Process finished.");
    } else {
        appendLogInfo_("Process terminated abnormally.");
    }
    this->unsetCursor();
}

void MainWindow::onOpenSettings()
{
    if (settings_widget_ != nullptr) {
        settings_widget_->setRscriptPath(app_settings_.rscript_path);
        settings_widget_->show();
    }
}

void MainWindow::onQuitClicked()
{
    QCoreApplication::quit();
}

void MainWindow::onAboutClicked()
{
    about_box_->exec();
}

void MainWindow::onShowAboutStartupToggled(bool show)
{
    app_settings_.show_about_when_startup = show;
    writeAppSettings_();
}

void MainWindow::onRscriptPathChanged(const QString &path)
{
    qDebug() << "onRscriptPathChanged() called";
    app_settings_.rscript_path = path;
    writeAppSettings_(); // Save the setting to local
}

void MainWindow::onPandocPathChanged(const QString& path)
{
    qDebug() << "onPandocPathChanged() called";
    app_settings_.pandoc_path = path;
    writeAppSettings_(); // Save the setting to local
}

bool MainWindow::getOligSettings_(OligomerParams &params)
{
    bool success = true;
    QVector<QString> label_names;

    params.is_pos = olig_pos_->isChecked();
    params.min_int = olig_abundance_cut_off_->getText().toFloat(&success);
    if (!success)
        label_names.push_back(olig_abundance_cut_off_->getLabelText());

    params.rt_min = olig_rt_begin_->getText().toFloat(&success);
    if (!success)
        label_names.push_back(olig_rt_begin_->getLabelText());

    params.rt_max = olig_rt_end_->getText().toDouble(&success);
    if (!success)
        label_names.push_back(olig_rt_end_->getLabelText());

    params.nl_min = olig_loss_cut_off_->getText().toFloat(&success);
    if (!success)
        label_names.push_back(olig_loss_cut_off_->getLabelText());

    params.round_nl = olig_loss_cal_accuracy_->getText().toInt(&success);
    if (!success)
        label_names.push_back(olig_loss_cal_accuracy_->getLabelText());

    params.round_differ = olig_end_grp_cal_accuracy_->getText().toInt(&success);
    if (!success)
        label_names.push_back(olig_end_grp_cal_accuracy_->getLabelText());

    params.ppm = 1e-6;

    params.folder_path = olig_ms2_folder_->getFilePath();
    if (params.folder_path.isEmpty())
        label_names.push_back(olig_ms2_folder_->getLabelText());

    params.db_matching = olig_db_matching_grp_->isChecked();
    if (params.db_matching) {
        params.db_path = olig_db_path_->getFilePath();
        if (params.db_path.isEmpty()) {
            label_names.push_back(olig_db_path_->getLabelText());
        }
    } else {
        params.db_path = "";
    }

    params.save_path = olig_output_file_->getFilePath();
    if (params.save_path.isEmpty())
        label_names.push_back(olig_output_file_->getLabelText());

    if (label_names.isEmpty()) {
        return true;
    } else {
        QString message = QString("Please set the following parameters: \n");

        for (int i = 0; i < label_names.size(); ++i)
            message += QString("[%1]\n").arg(label_names[i]);

        QMessageBox::information(
                    this,
                    tr("Warning"),
                    tr(message.toStdString().c_str())
                );
        return false;
    }
}

bool MainWindow::getHomoSettings_(HomologueParams &params)
{
    bool success = true;
    QVector<QString> label_names;

    params.batch_path = homo_seed_olig_file_->getFilePath();
    if (params.batch_path.isEmpty())
        label_names.push_back(homo_seed_olig_file_->getLabelText());

    params.peak_table_path = homo_ms1_peak_file_->getFilePath();
    if (params.peak_table_path.isEmpty())
        label_names.push_back(homo_ms1_peak_file_->getLabelText());

    params.filter = homo_deducting_blanks_grp_->isChecked();
    if (params.filter) {
        // Deducting blanks enabled
        params.bk_path = homo_blank_file_->getFilePath();
        if (params.bk_path.isEmpty())
            label_names.push_back(homo_blank_file_->getLabelText());

        params.rt_diff = homo_rt_tolerance_->getText().toFloat(&success);
        if (!success)
            label_names.push_back(homo_rt_tolerance_->getLabelText());

        params.mz_diff = homo_mz_tolerance_->getText().toFloat(&success);
        if (!success)
            label_names.push_back(homo_mz_tolerance_->getLabelText());

        params.proportion = homo_intensity_cut_off_->getText().toFloat(&success);
        if (!success)
            label_names.push_back(homo_intensity_cut_off_->getLabelText());
    } else {
        // Deducting blanks disabled
        params.bk_path = "";
        params.rt_diff = 0;
        params.mz_diff = 0;
        params.proportion = 0;
    }

    params.ppm = 1e-6;

    params.is_pos = homo_pos_->isChecked();

    params.error_1 = homo_mass_tolerance_1_->getText().toFloat(&success);
    if (!success)
        label_names.push_back(homo_mass_tolerance_1_->getLabelText());

    params.error_2 = homo_mass_tolerance_2_->getText().toFloat(&success);
    if (!success)
        label_names.push_back(homo_mass_tolerance_2_->getLabelText());

    params.rt_min = homo_rt_begin_->getText().toFloat(&success);
    if (!success)
        label_names.push_back(homo_rt_begin_->getLabelText());

    params.rt_max = homo_rt_end_->getText().toFloat(&success);
    if (!success)
        label_names.push_back(homo_rt_end_->getLabelText());

    params.rt_lim = homo_unstable_cut_off_->getText().toFloat(&success);
    if (!success)
        label_names.push_back(homo_unstable_cut_off_->getLabelText());

    params.annotation = homo_annotation_grp_->isChecked();

    if (params.annotation) {
        params.oligomer_db_path = homo_olig_db_file_->getFilePath();
        if (params.oligomer_db_path.isEmpty())
            label_names.push_back(homo_olig_db_file_->getLabelText());
    } else {
        params.oligomer_db_path = "";
    }

    params.save_path = homo_output_dir_->getFilePath();
    if (params.save_path.isEmpty())
        label_names.push_back(homo_output_dir_->getLabelText());

    if (label_names.isEmpty()) {
        return true;
    } else {
        QString message = QString("Please set the following parameters: \n");

        for (int i = 0; i < label_names.size(); ++i)
            message += QString("[%1]\n").arg(label_names[i]);

        QMessageBox::information(
                    this,
                    tr("Warning"),
                    tr(message.toStdString().c_str())
                );
        return false;
    }
}

bool MainWindow::getCongSettings_(CongenerParams &params)
{
    bool success = true;
    QVector<QString> label_names;

    params.batch_path = cong_seed_olig_file_->getFilePath();
    if (params.batch_path.isEmpty())
        label_names.push_back(cong_seed_olig_file_->getLabelText());

    params.peak_table_path = cong_ms1_peak_file_->getFilePath();
    if (params.peak_table_path.isEmpty())
        label_names.push_back(cong_ms1_peak_file_->getLabelText());

    params.filter = cong_deducting_blanks_grp_->isChecked();
    if (params.filter) {
        // Deducting blanks enabled
        params.bk_path = cong_blank_file_->getFilePath();
        if (params.bk_path.isEmpty())
            label_names.push_back(cong_blank_file_->getLabelText());

        params.rt_diff = cong_rt_tolerance_->getText().toFloat(&success);
        if (!success)
            label_names.push_back(cong_rt_tolerance_->getLabelText());

        params.mz_diff = cong_mz_tolerance_->getText().toFloat(&success);
        if (!success)
            label_names.push_back(cong_mz_tolerance_->getLabelText());

        params.proportion = cong_intensity_cut_off_->getText().toFloat(&success);
        if (!success)
            label_names.push_back(cong_intensity_cut_off_->getLabelText());
    } else {
        // Deducting blanks disabled
        params.bk_path = "";
        params.rt_diff = 0;
        params.mz_diff = 0;
        params.proportion = 0;
    }

    params.ppm = 1e-6;

    params.is_pos = cong_pos_->isChecked();

    params.end_gp_database_path = cong_end_grp_db_file_->getFilePath();
    if (params.end_gp_database_path.isEmpty())
        label_names.push_back(cong_end_grp_db_file_->getLabelText());

    params.error_1 = cong_mass_tolerance_1_->getText().toFloat(&success);
    if (!success)
        label_names.push_back(cong_mass_tolerance_1_->getLabelText());

    params.error_2 = cong_mass_tolerance_2_->getText().toFloat(&success);
    if (!success)
        label_names.push_back(cong_mass_tolerance_2_->getLabelText());

    params.save_path = cong_output_dir_->getFilePath();
    if (params.save_path.isEmpty())
        label_names.push_back(cong_output_dir_->getLabelText());

    if (label_names.isEmpty()) {
        return true;
    } else {
        QString message = QString("Please set the following parameters: \n");

        for (int i = 0; i < label_names.size(); ++i)
            message += QString("[%1]\n").arg(label_names[i]);

        QMessageBox::information(
                    this,
                    tr("Warning"),
                    tr(message.toStdString().c_str())
                );
        return false;
    }
}
