#include "mainwindow.h"

#include <QApplication>
#include <cstdlib>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;

    QIcon appIcon(":/Resources/Images/icon.ico");
    a.setWindowIcon(appIcon);

    w.show();
    return a.exec();
}
