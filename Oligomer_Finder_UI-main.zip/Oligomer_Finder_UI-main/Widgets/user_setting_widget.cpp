#include "user_setting_widget.h"
#include <QVBoxLayout>
#include <QGroupBox>

UserSettingWidget::UserSettingWidget(QString title, QWidget *parent) : QWidget(parent)
{
    QVBoxLayout* layout = new QVBoxLayout(this);

    layout->setMargin(0);

    rscript_path_editor_ = new FilePathEditor("Path of Rscript", FilePathEditor::OPEN_FILE, this);
    layout->addWidget(rscript_path_editor_);

    QString rscript_hint_content = "For Windows, you can find Rscript in the directory where R is installed.\n"
                                   "Its filename can be Rscript or Rscript.exe.\n"
                                   "For Mac, please launch a new terminal and key in \"where Rscript\" and \n"
                                   "then copy the returned path here.";

    QGroupBox* rscript_hint_grp = new QGroupBox();
    QVBoxLayout* rscript_hint_grp_layout = new QVBoxLayout(rscript_hint_grp);
    rscript_hint_ = new QLabel(rscript_hint_content, this);
    rscript_hint_grp_layout->addWidget(rscript_hint_);
    layout->addWidget(rscript_hint_grp);

    pandoc_path_editor_ = new FilePathEditor("Path of pandoc", FilePathEditor::OPEN_DIRECTORY, this);
    layout->addWidget(pandoc_path_editor_);

    QString pandoc_hint_content = "Please launch Rstudio. In the console, key in the following command \n"
                                  "\"Sys.getenv(\"RSTUDIO_PANDOC\")\" and copy the returned path here.";

    QGroupBox* pandoc_hint_grp = new QGroupBox();
    QVBoxLayout* pandoc_hint_grp_layout = new QVBoxLayout(pandoc_hint_grp);
    pandoc_hint_ = new QLabel(pandoc_hint_content, this);
    pandoc_hint_grp_layout->addWidget(pandoc_hint_);
    layout->addWidget(pandoc_hint_grp);

    ok_btn_ = new QPushButton("OK", this);
    layout->addWidget(ok_btn_);
    connect(ok_btn_, SIGNAL(clicked(bool)), this, SLOT(onOKBtnClicked()));

    setWindowTitle(title);
}

QString UserSettingWidget::getRscriptPath()
{
    return rscript_path_editor_ != nullptr? rscript_path_editor_->getFilePath() : "";
}

void UserSettingWidget::setRscriptPath(const QString& path)
{
    rscript_path_editor_->setFilePath(path);
}

QString UserSettingWidget::getPandocPath()
{
    return pandoc_path_editor_ != nullptr? pandoc_path_editor_->getFilePath() : "";
}

void UserSettingWidget::setPandocPath(const QString& path)
{
    pandoc_path_editor_->setFilePath(path);
}

void UserSettingWidget::onOKBtnClicked()
{
    emit onRscriptPathChanged(rscript_path_editor_->getFilePath());
    emit onPandocPathChanged(pandoc_path_editor_->getFilePath());
    this->hide();
}
