#ifndef USER_SETTING_WIDGET_H
#define USER_SETTING_WIDGET_H

#include <QWidget>
#include "file_path_editor.h"
#include <QLabel>
#include <QPushButton>

/*
 * UserSettingWidget is a widget for users to specify the settings for the tool.
 */
class UserSettingWidget : public QWidget
{
    Q_OBJECT
public:
    explicit UserSettingWidget(QString title = "", QWidget *parent = nullptr);

    QString getRscriptPath();
    void setRscriptPath(const QString& path);

    QString getPandocPath();
    void setPandocPath(const QString& path);

signals:
    void onRscriptPathChanged(const QString& path);
    void onPandocPathChanged(const QString& path);

private slots:
    void onOKBtnClicked();

private:
    FilePathEditor* rscript_path_editor_;
    QLabel* rscript_hint_;

    FilePathEditor* pandoc_path_editor_;
    QLabel* pandoc_hint_;

    QPushButton* ok_btn_;
};

#endif // USER_SETTING_WIDGET_H
