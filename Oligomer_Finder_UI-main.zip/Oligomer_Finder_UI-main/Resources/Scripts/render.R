library(rmarkdown)

# Function to read a configuration file and save settings into a list
read_config_file <- function(file_path) {
  config_list <- list()
  
  # Read the configuration file line by line
  con <- file(file_path, "r")
  while (length(line <- readLines(con, n = 1)) > 0) {
    # Split each line into setting and value
    parts <- strsplit(line, "=")[[1]]
    
    if (length(parts) == 2) {
      setting <- trimws(parts[1])
      
      # Try to convert the value to a numeric type
      numeric_val <- as.numeric(parts[2])
      
      if (!is.na(numeric_val)) {
        # numeric
        value <- numeric_val
      } else {
        # string
        value <- trimws(parts[2])
      }
      
      config_list[[setting]] <- value
    }
  }
  close(con)
  
  return(config_list)
}

# Get the command-line arguments
args <- commandArgs(trailingOnly = TRUE)

if (length(args) != 4) {
    quit()
}

# Sequence of arguments
# 1. Method: Oligomer, Homologue, Congener
# 2. Configuration file path
# 3. Rmd file path
# 4. pandoc path
method = args[1]
setting_path = args[2]
rmd_path = args[3]
pandoc_path = args[4]

# Read the setting file
read_params <- read_config_file(setting_path)

params <- list()

# Define parameter values
if (method == "Oligomer") {
    params <- list(
        Mode = read_params$Mode,
        minint = read_params$minint,
        RTmin = read_params$RTmin,
        RTmax = read_params$RTmax,
        NLmin = read_params$NLmin,
        Round_NL = read_params$Round_NL,
        Round_Differ = read_params$Round_Differ,
        ppm = read_params$ppm,
        folder_path = read_params$folder_path,
        Databasematching = read_params$Databasematching,
        database_path = read_params$database_path,
        save_path = read_params$save_path
    )
} else if (method == "Homologue") {
    params <- list(
        batch_patch = read_params$batch_patch,
        peak_table_path = read_params$peak_table_path,
        BK_path = read_params$BK_path,
        ppm = read_params$ppm,
        filter = read_params$filter,
        RT_diff = read_params$RT_diff,
        mz_diff = read_params$mz_diff,
        proportion = read_params$proportion,
        Mode = read_params$Mode,
        error1 = read_params$error1,
        error2 = read_params$error2,
        RTmin = read_params$RTmin,
        RTmax = read_params$RTmax,
        RTlim = read_params$RTlim,
        Annotate = read_params$Annotate,
        oligomer_database_path = read_params$oligomer_database_path,
        save_path = read_params$save_path
    )
} else if (method == "Congener") {
    params <- list(
        batch_patch = read_params$batch_patch,
        peak_table_path = read_params$peak_table_path,
        BK_path = read_params$BK_path,
        ppm = read_params$ppm,
        filter = read_params$filter,
        RT_diff = read_params$RT_diff,
        mz_diff = read_params$mz_diff,
        proportion = read_params$proportion,
        Mode = read_params$Mode,
        End_group_database_path = read_params$End_group_database_path,
        error1 = read_params$error1,
        error2 = read_params$error2,
        save_path = read_params$save_path
    )
} else {
    quit()
}

Sys.setenv(RSTUDIO_PANDOC=pandoc_path)

# Render the Rmd document with parameters
rmarkdown::render(rmd_path, params = params)