#ifndef FINDERPARAMS_H
#define FINDERPARAMS_H
#include <QString>

/*
 * In this file, several data structures are defined to save finder parameters.
 */
struct OligomerParams {
   bool is_pos;
   float min_int;
   float rt_min;
   float rt_max;
   float nl_min;
   int round_nl;
   int round_differ;
   float ppm;
   QString folder_path; // MS2 peak spots
   bool db_matching;
   QString db_path;
   QString save_path;
};

struct HomologueParams {
    QString batch_path; // seed oligomer table
    QString peak_table_path; // MS1 peak table
    QString bk_path; // blank peak table
    float ppm;
    bool filter; // use filter or not
    float rt_diff;
    float mz_diff;
    float proportion;
    bool is_pos;
    float error_1;
    float error_2;
    float rt_min;
    float rt_max;
    float rt_lim;
    bool annotation;
    QString oligomer_db_path;
    QString save_path;
};

struct CongenerParams {
    QString batch_path; // seed oligomer table
    QString peak_table_path; // MS1 peak table
    QString bk_path; // blank peak table
    float ppm;
    bool filter; // use filter or not
    float rt_diff;
    float mz_diff;
    float proportion;
    bool is_pos;
    QString end_gp_database_path;
    float error_1;
    float error_2;
    QString save_path;
};

#endif // FINDERPARAMS_H
